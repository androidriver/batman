#include <stdio.h>
#include "osal.h"


void gprs_task(void)
{
    printf("GPRS Task is running.\n");

}
