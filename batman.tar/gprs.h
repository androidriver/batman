#ifndef __GPRS_H_
#define __GPRS_H_

#ifdef __cplusplus
extern "C" {
#endif

extern void gprs_task(void);
//extern void

#ifdef __cplusplus
}
#endif

#endif
