#ifndef __VOLT_MEAS_H_
#define __VOLT_MEAS_H_

#ifdef __cplusplus
extern "C" {
#endif

extern void volt_meas_task(void);
//extern void

#ifdef __cplusplus
}
#endif

#endif
