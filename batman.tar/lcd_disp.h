#ifndef __LCD_DISP_H_
#define __LCD_DISP_H_

#ifdef __cplusplus
extern "C" {
#endif

extern void lcd_disp_task(void);
//extern void

#ifdef __cplusplus
}
#endif

#endif
